

module Main where

import Week2
import JoeJill
import Form2Bool
import CNF


main = do
    --runJoeJillTests
    runCnfTests 1000
