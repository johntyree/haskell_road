

Problems which were not haskell implementation problems, but which we did
anyway, are scattered throughout the Sol1 and Sol2 modules as comments.

Our bonus exercises are in Exerc1.hs


- John and Alex
